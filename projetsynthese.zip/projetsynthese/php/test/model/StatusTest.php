<?php

use PHPUnit\Framework\TestCase;
require_once __DIR__.'/../../src/model/Status.php';

class StatusTest extends TestCase
{
    /**
     * @dataProvider getStatusProvider
     */
    public function testGetIdStatus(Status $status, int $id, string $lib){
        $this->assertSame($status->getIdStatus(),$id);
    }

    /**
     * @dataProvider getStatusProvider
     */
    public function testGetLbStatus(Status $status, int $id, string $lib){
        $this->assertEquals($status->getLbStatus(),$lib);
    }


    /**
     * @dataProvider setStatusProvider
     */
    public function testSetIdStatus(Status $status, int $id, string $lib){
        $status->setIdStatus($id);
        $this->assertEquals($status->getIdStatus(), $id);
    }


    /**
     * @dataProvider setStatusProvider
     */
    public function testSetLbStatus(Status $status, int $id, string $lib){
        $status->setLbStatus($lib);
        $this->assertEquals($status->getLbStatus(), $lib);
    }



    public function getStatusProvider(){
        return [
            [new Status(1,"cc"),1,"cc"],
            [new Status(2,"oui"),2,"oui"]
        ];
    }

    public function setStatusProvider(){
        return [
           [new Status(1,"a"),2,"b"],
           [new Status(3,"c"),3,"d"]
        ];
    }

}