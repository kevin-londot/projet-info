<?php
require_once __DIR__ . '/model/StatusDAO.php';
require_once __DIR__ . '/model/UserDAO.php';
require_once __DIR__ . '/model/BookDAO.php';
require_once __DIR__ . '/model/ChoiceDAO.php';
require_once __DIR__ . '/model/PageDAO.php';
require_once __DIR__ . '/model/CommentDAO.php';


require_once __DIR__ . '/mysql/StatusMySQLDAO.php';
require_once __DIR__ . '/mysql/UserMySQLDAO.php';
require_once __DIR__ . '/mysql/RoleMySQLDAO.php';
require_once __DIR__ . '/mysql/BookMySQLDAO.php';
require_once __DIR__ . '/mysql/ChoiceMySQLDAO.php';
require_once __DIR__ . '/mysql/PageMySQLDAO.php';
require_once __DIR__ . '/mysql/CommentMySQLDAO.php';

require_once __DIR__ . '/../connection/Persistance.php';

class DAOFactory
{

    const PERSISTANCE = Persistance::MYSQL;

    private function __construct()
    {}

    private static function getDAO($typeDAO): DAO
    {
        switch (self::PERSISTANCE) {
            case Persistance::MYSQL:
                return ($typeDAO . 'MySQLDAO')::getInstance();
            default:
                return null;
        }
    }

    public static function getStatusDAO(): StatusDAO
    {
        return self::getDAO('Status');
    }
    public static function getUserDAO(): UserDAO
    {
        return self::getDAO('User');
    }
    public static function getRoleDAO(): RoleDAO
    {
        return self::getDAO('Role');
    }
    public static function getBookDAO(): BookDAO
    {
        return self::getDAO('Book');
    }
    public static function getChoiceDAO(): ChoiceDAO
    {
        return self::getDAO('Choice');
    }
    public static function getCommentDAO(): CommentDAO
    {
        return self::getDAO('Comment');
    }
    public static function getPageDAO(): PageDAO
    {
        return self::getDAO('Page');
    }
}
