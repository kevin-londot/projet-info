<?php
require_once __DIR__ . '/../DAO.php';

interface BookDAO extends DAO{

    public function getByAuthor(User $user);

    public function getByStatus(Status $status);

    public function getByStatusAndAuthor(User $user,Status $status );
}