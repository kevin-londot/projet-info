<?php
require_once __DIR__ . '/../DAO.php';

interface CommentDAO extends DAO{

    public function getByBook(Book $book);

    public function getByAuthor(User $user);
    
}