<?php
require_once __DIR__ . '/../DAO.php';

interface ChoiceDAO extends DAO{

    public function getBySourcePage(Page $pageSrc);
    public function getByDestinationPage(Page $pageDst);
}