<?php
require_once __DIR__ . '/../DAO.php';


interface PageDAO extends DAO{

    public function getByBook(Book $book);

}