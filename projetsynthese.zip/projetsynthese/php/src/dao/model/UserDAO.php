<?php
require_once __DIR__ . '/../DAO.php';

interface UserDAO extends DAO{

    public function getByRole(Role $role);
    public function getByLog(string $username, string $password);
}