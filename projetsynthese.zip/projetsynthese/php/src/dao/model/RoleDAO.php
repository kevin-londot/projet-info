<?php
require_once __DIR__ . '/../DAO.php';

interface RoleDAO extends DAO{

}