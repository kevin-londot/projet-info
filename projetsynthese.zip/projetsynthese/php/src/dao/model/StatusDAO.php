<?php
require_once __DIR__ . '/../DAO.php';

interface StatusDAO extends DAO{
    
}