<?php

class Persistance{
    
    const MYSQL = 0;
    const XML = 1;
    
    private function __construct(){}
    
}