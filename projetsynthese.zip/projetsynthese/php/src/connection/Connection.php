<?php


class Connection
{
    const HOST = 'devbdd.iutmetz.univ-lorraine.fr';
    const DBNAME = 'ganglof14u_pjSynthese';
    const CHARSET = 'utf8';
    const USERNAME = 'ganglof14u_appli';
    const PASSWD = '31202668';

    /* @var PDO $bdd */
    private $bdd;
    /* @var Connection $instance*/
    private static $instance = null;

    private function __construct(){
        $this->bdd = new PDO(
                'mysql:host='.self::HOST.';dbname='.self::DBNAME.';charset='.self::CHARSET,
                self::USERNAME,
                self::PASSWD);
    }

    public static function getInstance()
    {
        if (is_null(self::$instance)){
            self::$instance = new self();
        }
        return self::$instance;
    }


    public static function getInstanceBdd(){
        return self::getInstance()->getBdd();
    }


    /**
     * @return PDO
     */
    public function getBdd(): PDO
    {
        return $this->bdd;
    }

    /**
     * @param PDO $bdd
     */
    public function setBdd(PDO $bdd): void
    {
        $this->bdd = $bdd;
    }





}