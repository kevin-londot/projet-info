<?php
$username ="kevin";
$password="code";

if(isset($username)&& isset($password)){
    $user=DAOFactory::getUserDAO()->getByLog($username,$password);
    if($user==0){
        $_SESSION["session"]= new Session(User::getGuest(),Session::NOT_LOGGED);
    }
    else{
        $_SESSION["session"]= new Session($user,Session::LOGGED);
    }
}

