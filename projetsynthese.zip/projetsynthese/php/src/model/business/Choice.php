<?php

class Choice
{
    private $idChoice;
    private $description;
    private $SourcePage;
    private $DestinationPage;



}
