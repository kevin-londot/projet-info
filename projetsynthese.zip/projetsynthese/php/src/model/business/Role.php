<?php

class Role
{

    /* @var int */
    protected $idRole;
    /* @var string */
    protected $lbRole;
    const ID_GUEST_ROLE = 0;
    const LIB_GUEST_ROLE = "Guest";

    /**
     * Role constructor.
     * @param int $idRole
     * @param string $lbRole
     */
    public static function getRoleGuest():Role
    {
        return new Role(self::ID_GUEST_ROLE, self::LIB_GUEST_ROLE);
    }

    public function __construct(int $idRole, string $lbRole)
    {
        $this->idRole = $idRole;
        $this->lbRole = $lbRole;
    }

    /**
     * @return int
     */
    public function getIdRole(): int
    {
        return $this->idRole;
    }

    /**
     * @param int $idRole
     */
    public function setIdRole(int $idRole): void
    {
        $this->idRole = $idRole;
    }

    /**
     * @return string
     */
    public function getLbRole(): string
    {
        return $this->lbRole;
    }

    /**
     * @param string $lbRole
     */
    public function setLbRole(string $lbRole): void
    {
        $this->lbRole = $lbRole;
    }




}
