<?php

class Comment
{
    /* @var User */
    protected $author;
    /* @var DateTime */
    protected $date;
    /* @var Book */
    protected $book;
    /* @var string */
    protected $content;

    /**
     * Comment constructor.
     * @param User $author
     * @param DateTime $date
     * @param Book $book
     * @param string $content
     */
    public function __construct(User $author, DateTime $date, Book $book, $content)
    {
        $this->author = $author;
        $this->date = $date;
        $this->book = $book;
        $this->content = $content;
    }

    /**
     * @return User
     */
    public function getAuthor()
    {
        return $this->author;
    }

    /**
     * @param User $author
     */
    public function setAuthor($author)
    {
        $this->author = $author;
    }

    /**
     * @return DateTime
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * @param DateTime $date
     */
    public function setDate($date)
    {
        $this->date = $date;
    }

    /**
     * @return Book
     */
    public function getBook()
    {
        return $this->book;
    }

    /**
     * @param Book $book
     */
    public function setBook($book)
    {
        $this->book = $book;
    }

    /**
     * @return string
     */
    public function getContent()
    {
        return $this->content;
    }

    /**
     * @param string $content
     */
    public function setContent($content)
    {
        $this->content = $content;
    }
}