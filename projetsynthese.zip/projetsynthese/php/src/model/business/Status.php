<?php

class Status
{
    /* @var int $idStatus*/
    private $idStatus;
    /* @var string $lbStatus*/
    private $lbStatus;

    /**
     * Status constructor.
     * @param int $idStatus
     * @param string $lbStatus
     */
    public function __construct(int $idStatus, string $lbStatus)
    {
        $this->idStatus = $idStatus;
        $this->lbStatus = $lbStatus;
    }

    /**
     * @return int
     */
    public function getIdStatus(): int
    {
        return $this->idStatus;
    }

    /**
     * @param int $idStatus
     */
    public function setIdStatus(int $idStatus): void
    {
        $this->idStatus = $idStatus;
    }

    /**
     * @return string
     */
    public function getLbStatus(): string
    {
        return $this->lbStatus;
    }

    /**
     * @param string $lbStatus
     */
    public function setLbStatus(string $lbStatus): void
    {
        $this->lbStatus = $lbStatus;
    }

    public function __toString()
    {

        return "Status : ".$this->idStatus." - ".$this->lbStatus;
    }

}
