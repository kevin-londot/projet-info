<?php

class Page
{
    private $idPage;
    private $numPage;
    private $idBook;
    private $text;
}