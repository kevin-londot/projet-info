﻿-- phpMyAdmin SQL Dump
-- version 4.0.10deb1ubuntu0.1
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Dim 09 Décembre 2018 à 14:57
-- Version du serveur: 5.5.61-MariaDB-1ubuntu0.14.04.1
-- Version de PHP: 7.1.15-1+ubuntu14.04.1+deb.sury.org+2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `londot2u.pj`
--

-- --------------------------------------------------------

--
-- Structure de la table `Client`
--

CREATE TABLE IF NOT EXISTS `Client` (
  `NumClient` int(11) NOT NULL,
  `NomClient` varchar(20) NOT NULL,
  `Ville` varchar(20) NOT NULL,
  PRIMARY KEY (`NumClient`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `Compte`
--

CREATE TABLE IF NOT EXISTS `Compte` (
  `NumCompte` int(11) NOT NULL,
  `NumClient` int(11) NOT NULL,
  `DateOuverture` date NOT NULL,
  `Solde` decimal(10,2) NOT NULL,
  `PMVR` decimal(10,2) NOT NULL,
  PRIMARY KEY (`NumCompte`),
  KEY `NumClient` (`NumClient`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `Operation`
--

CREATE TABLE IF NOT EXISTS `Operation` (
  `NoOpe` int(11) NOT NULL,
  `NoCompte` int(11) NOT NULL,
  `CodeValeur` varchar(3) NOT NULL,
  `DateOpe` date NOT NULL,
  `Nature` varchar(1) NOT NULL,
  `Qte` int(11) NOT NULL,
  `Montant` decimal(10,2) NOT NULL,
  PRIMARY KEY (`NoOpe`),
  KEY `CodeValeur` (`CodeValeur`),
  KEY `NoCompte` (`NoCompte`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `Portefeuille`
--

CREATE TABLE IF NOT EXISTS `Portefeuille` (
  `NumCompte` int(11) NOT NULL,
  `CodeValeur` varchar(3) NOT NULL,
  `Quantite` int(11) NOT NULL,
  `PAM` decimal(10,2)NOT NULL,
  PRIMARY KEY (`NumCompte`,`CodeValeur`),
  KEY `CodeValeur` (`CodeValeur`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `Secteur`
--

CREATE TABLE IF NOT EXISTS `Secteur` (
  `CodeSecteur` varchar(3) NOT NULL,
  `LibSecteur` varchar(20) NOT NULL,
  PRIMARY KEY (`CodeSecteur`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `Valeur`
--

CREATE TABLE IF NOT EXISTS `Valeur` (
  `Codevaleur` varchar(3) NOT NULL,
  `Denomination` varchar(20) NOT NULL,
  `CodeSecteur` varchar(3) NOT NULL,
  `Indice` varchar(15) NOT NULL,
  `Cours` decimal(10,2) NOT NULL,
  PRIMARY KEY (`Codevaleur`),
  KEY `CodeSecteur` (`CodeSecteur`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `Compte`
--
ALTER TABLE `Compte`
  ADD CONSTRAINT `Compte_ibfk_1` FOREIGN KEY (`NumClient`) REFERENCES `Client` (`NumClient`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `Operation`
--
ALTER TABLE `Operation`
  ADD CONSTRAINT `Operation_ibfk_2` FOREIGN KEY (`CodeValeur`) REFERENCES `Valeur` (`Codevaleur`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Operation_ibfk_1` FOREIGN KEY (`NoCompte`) REFERENCES `Compte` (`NumCompte`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `Portefeuille`
--
ALTER TABLE `Portefeuille`
  ADD CONSTRAINT `Portefeuille_ibfk_2` FOREIGN KEY (`CodeValeur`) REFERENCES `Valeur` (`Codevaleur`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Portefeuille_ibfk_1` FOREIGN KEY (`NumCompte`) REFERENCES `Compte` (`NumCompte`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `Valeur`
--
ALTER TABLE `Valeur`
  ADD CONSTRAINT `Valeur_ibfk_1` FOREIGN KEY (`CodeSecteur`) REFERENCES `Secteur` (`CodeSecteur`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
 --INSERT
 --Insert Client
 INSERT INTO Client(NumClient, NomClient, Ville)
 VALUES
 (101, 'Prudent', 'Nancy'),
 (102, 'Trader', 'Metz'),
 (103, 'PasLesMoyens', 'Metz');
 --Insert Compte
 INSERT INTO Compte (NumCompte, NumClient, DateOuverture, Solde,PMVR)
 VALUES
 (1, 101, 10/10/10, 1000.00,000.00),
 (2, 102, 11/11/11, 8700.00,200.00),
 (3, 102, 12/12/12, 1000.00 ,000.00),
 (4, 103, 09/09/09, 100.00 ,000.00);
 --Insert Secteur
 INSERT INTO Secteur(CodeValeur, LibSecteur)
 VALUES
 ('S1', 'Energies'),
 ('S2', 'Automobile'),
 ('S3', 'Pharmacie');
 --Insert Valeur
 INSERT INTO Valeur(CodeValeur, Denomination, CodeSecteur,Indice,Cours)
 VALUES
 ('EDF', 'EDF', 'S1','SBF120',14.00),
 ('RNO', 'RENAULT', 'S2','CAC40',70.00),
 ('SAN', 'SANOFI', 'S3','CAC40',75.00);
 --Insert Portefeuille
 INSERT INTO Portefeuille(NumCompte,CodeValeur, Quantite,PAM)
 VALUES
 (1, 'EDF', 200,13.00),
 (1, 'RNO', 20,70.00),
 (2, 'EDF', 100,15.00);
 --Insert Operation
 INSERT INTO Operation (NoOPe, NoCompte, CodeValeur, DateOpe,Nature,Qte,Montant)
 VALUES
 ('1', '1', 'EDF', 18/09/01 ,'A',100,1200.00),
 ('2', '1', 'EDF', 18/10/15,'A',100,1400.00),
 ('3', '1', 'RNO', 18/10/30 ,'A',20,1400.00),
 ('4', '2', 'EDF', 18/07/01 ,'A',200,3000.00),
 ('5', '2', 'EDF', 18/10/15 ,'V',100,1400.00),
 ('6', '2', 'RNO', 18/09/01 ,'A',30,1800.00),
 ('7', '2', 'RNO', 18/10/30 ,'V',30,2100.00);
--Update
--update de solde
UPDATE Compte
SET Solde = Solde + CASE (SELECT Nature FROM Operation  WHERE NoOpe = (SELECT Max(NoOpe) FROM Operation))
				  WHEN 'A' THEN (select Montant from Operation where NoOpe = (SELECT Max(NoOpe) FROM Operation))
				  WHEN 'V' THEN (select -Montant from Operation where NoOpe = (SELECT Max(NoOpe) FROM Operation))
				  END
WHERE NumCompte In (SELECT NoCompte FROM Operation WHERE NoOpe = (SELECT Max(NoOpe) FROM Operation))
--Update de Quantité
UPDATE Portefeuille
SET Quantite= Quantite +CASE (Select Nature From Opération, Portefeuille Where Opération.CodeValeur = Portefeuille.CodeValeur And Opération.NoCompte = Portefeuille.NumCompte and noOpé=(select count(NoOpe) from operation))
				  WHEN 'A' THEN (select Qte from Operation )
				  WHEN 'V' THEN (select -Qte from Operation )
				  END
--Update de PAM
update Portefeuille
set Pam= (Select SUM(Montant)from Operation where Portefeuille.NumCompte=Operation.NoCompte and Portefeuille.CodeValeur=Operation.CodeValeur and Nature='A' ) /(Select Sum(Qte) from Operation where Portefeuille.NumCompte=Operation.NoCompte and Portefeuille.CodeValeur=Operation.CodeValeur and Nature='A')
--Update de PMVR
Update Compte
set PMVR= (Select SUM(Montant) From Operation,Portefeuille where Compte.NumCompte=Operation.NoCompte and Compte.NumCompte=Portefeuille.NumCompte and NoOpe=(Select count(NoOpe) From Operation) -(Select Qte*PAM From Portefeuille,Operation where Compte.NumCompte=Portefeuille.NumCompte and Portefeuille.CodeValeur=Operation.CodeValeur))
--DELETE
delete Portefeuille
DELETE from Portefeuille
where NumCompte Not exist(select NoCompte From Operation)
and CodeValeur Not Exist(Select CodeValeur From Operation)
--Requete SQL
--1)
Select CodeValeur, Denomination
From Valeur v,Secteur s
Where v.CodeSecteur=s.CodeSecteur
And LibSecteur='Pharmacie'
And Indice='CAC40'
--2)
Select Distinct(CodeValeur),Denomination
From Valeur v,Compte c,Operation o
Where v.CodeValeur =o.CodeValeur
and o.NoCompte=c.NumCompte
and DateOuverture >'01/01/11'
--3)
Select Distinct(NomClient),Ville
From Client cl,Compte c,Portefeuille p
where cl.NumClient=c.NumClient
and c.NumCompte=p.NumCompte
and CodeValeur='RNO'
--4)
Select Distinct(NomClient),Ville
From Client cl ,Compte c,Portefeuille p,Valeur v,Secteur s
where cl.NumClient =c.NumClient
and c.NumCompte=p.NumCompte
and p.CodeValeur=v.CodeValeur
and v.CodeSecteur=s.CodeSecteur
and LibSecteur='Energies'
and Indice='SBF120'
--5)
Select NomClient, Ville
From Client cl
Where  cl.NumClient NOT IN (Select c.NumClient From Compte c, Portefeuille p Where c.NumCompte = p.NumCompte)
--6)

--7)
Select c.NumCompte, Solde, COALESCE(SUM(Quantite*PAM),0) AS TotalPortefeuille
FROM Compte c LEFT JOIN Portefeuille p ON c.NumCompte=p.NumCompte
GROUP BY c.NumCompte

--8)
Select distinct(NomClient)
From Client cl,Compte c,Portefeuille p
Where cl.NumClient=c.NumClient
and c.NumCompte=p.NumCompte
and Solde <=1000.00
and Quantite*PAM >1000

--9)
Select NomClient,Ville
from Client cl,Compte c ,Portefeuille p
Where cl.NumClient=c.NumClient
and c.Numcompte=p.Numcompte
Having Count(CodeValeur)>=2
--10)
Select NumCompte,LibSecteur
From Compte c ,Portefeuille p, Valeur v,Secteur s
where c.NumCompte=p.Numcompte
and p.CodeValeur=v.CodeValeur
and v.CodeSecteur=s.CodeSecteur
Group By NumCompte
Order By LibSecteur DESC
--11)
Select c.NumCompte,NomClient,Ville
From Compte c,Client cl, Secteur s,Valeur v,Portefeuille p
where cl.NumClient=c.NumClient
and c.NumCompte=p.NumCompte
and p.CodeValeur=v.CodeValeur
and v.CodeSecteur=s.CodeSecteur
and LibSecteur='Energies'
and p.CodeValeur <>'RNO'
